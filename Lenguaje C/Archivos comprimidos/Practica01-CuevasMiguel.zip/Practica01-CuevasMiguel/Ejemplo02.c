/*
Nombre: Miguel Angel Cuevas Gonzalez 
Matricula: #1279713
*/

#include <stdio.h>
#include <stdlib.h>

int main(void){
    printf("\n");
    printf("                                                   |-(*)-|\n");
    printf("                        /\"\\                 .       .: \n");
    printf("    Over Here!         \( 00|                       :.\n");
    printf(" Help! Please Help !!  _\\=/_\n");
    printf("                      /  _  \\              ____________\n");
    printf("                     //|/.\\|\\\\           / \n");
    printf("                    ||_ \\_/ _||_________ /\n");
    printf("_____              /|| |\\ /| ||  \n");
    printf("     \\___________/  #  \\_ _/ #    \n");
    printf("                       | | | \n");
    printf("                       | | | \n");
    printf("                       ()|()) \n");
    printf("                       | | | \n");
    printf("______________________/_]_[_\\__________________________\n");

    return EXIT_SUCCESS;
}