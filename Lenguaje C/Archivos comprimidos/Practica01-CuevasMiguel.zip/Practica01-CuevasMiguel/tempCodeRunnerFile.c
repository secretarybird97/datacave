
    printf("          |    | \n");