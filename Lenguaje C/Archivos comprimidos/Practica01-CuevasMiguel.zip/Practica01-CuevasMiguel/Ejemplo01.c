/*
Nombre: Miguel Angel Cuevas Gonzalez 
Matricula: #1279713
*/

#include <stdio.h>
#include <stdlib.h>

int main(void){
    printf("\n");
    printf("           /\"\\  \n");
    printf("          \( 00|\n");
    printf("           \\  / \n");
    printf("         /      \\  \n");
    printf("        / |/ \\|  \\  \n");
    printf("       | _ \\  / _ |  \n");
    printf("       |  |    |  |  \n");
    printf("          \\_  _/    \n");
    printf("          |    | \n");
    printf("          |    | \n");
    printf("          (    ) \n");
    printf("          |    | \n");
    printf("          _    _   \n");
    system("PAUSE>NULL");


    return EXIT_SUCCESS;
}