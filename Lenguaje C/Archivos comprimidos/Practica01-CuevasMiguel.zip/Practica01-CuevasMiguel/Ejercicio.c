/*
Nombre: Miguel Angel Cuevas Gonzalez 
Matricula: #1279713
*/

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    printf("    __  ____                  __   ______                          \n");
    printf("   /  |/  (_)___ ___  _____  / /  / ____/_  _____ _   ______ ______\n");
    printf("  / /|_/ / / __ `/ / / / _ \\/ /  / /   / / / / _ \\ | / / __ `/ ___/\n");
    printf(" / /  / / / /_/ / /_/ /  __/ /  / /___/ /_/ /  __/ |/ / /_/ (__  ) \n");
    printf("/_/  /_/_/\\__, /\\__,_/\\___/_/   \\____/\\__,_/\\___/|___/\\__,_/____/  \n");
    printf("         /____/                                                    \n");
    printf("                        _               _       _         \n");
    printf("        |U|niversidad  //\\utonoma  de  [|}aja  ((alifornia\n");
    printf("        `-'                                               \n");

    return EXIT_SUCCESS;
}