/*
Nombre: Miguel Angel Cuevas Gonzalez 
Matricula: #1279713
*/


#include <stdio.h>
#include <stdlib.h>

int main(void){
    int a, b;
    printf("\nNumero a = ");
    scanf("%d", &a);
    printf("Numero b = ");
    scanf("%d", &b);
    printf("\nLa suma de a y b es igual a %d", a+b);

    return EXIT_SUCCESS;
}