
    scanf("%f", &cal);